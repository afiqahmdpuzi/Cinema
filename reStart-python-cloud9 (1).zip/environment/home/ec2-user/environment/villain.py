print("Can you guess how old is Vanessa?")
import random
num = random.randint(20, 30)
guess = None

while guess != num:
    guess = input("Guess how old she is between 20 and 30: ")
    guess = int(guess)
    
    if guess == num:
        print("Yo you got it right!")
        print(" ")
        print("Sorry we don't actually know her age hehe")
    else:
        print("Awe man, you got it wrong! ehe! try again!")
        print("Guess it right or she'll get mad!")
    
        
