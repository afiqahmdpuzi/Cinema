print("What do you think Michelle's favourite animal is?")
import random
animals = ['cat', 'monkey', 'horse', 'shark', 'rabbit', 'elephant', 'snake', 'llama']
word = random.choice(animals)
guess = None

while guess != word:
    guess = input("Guess her favourite animal! ")
    
    if guess == word:
        print("Oh, you actually guessed right?")
        print(" ")
        print("But sorry! Her favourite animal is actually a dog! ")
    else:
        print("Awe man, you got it wrong!")
        print("You might get it right if you try again! ")
    
