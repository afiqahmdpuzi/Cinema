print("Can you guess the number?")
import random
num = random.randint(1, 10)
guess = None



while guess != num:
guess = input("Guess the number between 1 and 10: ")
guess = int(guess)

if guess == num:
print("Yo you got it right!")
print(" ")
print("YOU GOT IT TUBBY JIGGLYBUTT")
else:
print("Awe man, you got it wrong! ehe! try again!")
